//Muhhamad Zain Ali U64584914
//Jose Jimenez U01810535



#include "HuffmanTree.hpp"
#include <map>
#include <string>
#include <sstream>
#include <algorithm>
#include <iostream>
#include <deque>


//function to convert string to 1's and 0's
std::string HuffmanTree::compress(const std::string inputStr){
    std::string output="";
    std::map<char, int> myMap; //map of char and int to store character and its frequency
    for(size_t i=0;i<inputStr.size();i++){
        myMap[inputStr[i]]++; //add characters to map and increment frequency
    }

  HeapQueue<HuffmanNode*, HuffmanNode::Compare> hq; //create heap to store nodes from map  
  //compare perimeter is used to compare the two nodes while putting them in the priority heap queue

  //iterates over map, makes node from character and frequency. Then puts it into queue that sorts itself
  for(auto it = myMap.begin(); it != myMap.end(); it++){
      HuffmanNode* hnode = new HuffmanNode(it->first,it->second);
      hq.insert(hnode); //creates the minheap
  }

  while(hq.size()>1){
    HuffmanNode* firstnode = hq.min(); //gets the min node
    hq.removeMin();//removes the minimum node from the priority queue

    HuffmanNode* secondnode = hq.min();//gets the min node
    hq.removeMin();//removes it from the priority queue

    size_t newFrequency = firstnode->getFrequency() + secondnode->getFrequency();//total frequency for 2 nodes
    HuffmanNode* newNode = new HuffmanNode('\0',newFrequency,nullptr,firstnode,secondnode); //creates new node
    firstnode->parent=secondnode->parent=newNode; //making the new node parent of the 2 minimum nodes
    hq.insert(newNode); //insert the new node back in the heapqueue
    
    
  }
  std::map<char, std::string> encodedMap; //another map to store character and encoded string

  HuffmanNode* TreeRoot = hq.min(); //gets the root node
  treeRoot = hq.min();
  std::string testingString = ""; //initializes encoded string
  encode(TreeRoot, testingString, encodedMap);//call to helper function to encode
  
  for(size_t i=0;i<inputStr.size();i++){
    output+=encodedMap[inputStr[i]]; //adds the encoded string to the output string
  }

  return output; //return the output string showing the encoded message
}

void HuffmanTree::encode(HuffmanNode *root, std::string str, std::map<char, std::string> &huffmanCode)
{   
    if(root==NULL){
    return; //if we go below the leaf node
  }
  if(root->isLeaf()){
    huffmanCode[root->getCharacter()]=str; //if we reach a leaf node, add the character and its encoded string to the map
  }
  //we use recursive functions to traverse left and then right while updating the str accordingly
  encode(root->left, str + "0",huffmanCode);//add 0 when traversing to left
  encode(root->right, str + "1",huffmanCode);//add 1 when traversing to right
}

//this fucntion serializes the tree and returns it in a string format by calling the traverse_post_ser helper fucntion with the root node 
std::string HuffmanTree::serializeTree() const 
{
   std::string ser = traverse_post_ser(treeRoot);

   return ser;
}

//this helper fucntion takes the root of the huffman tree node and traverses it in post order. If it reaches  a leaf it adds an L before the node value. a B for branches
std::string HuffmanTree::traverse_post_ser(HuffmanNode* node) const 
{
  if(node == NULL)
  {
    return "";
  }

    std::string left = traverse_post_ser(node->left);
    std::string right = traverse_post_ser(node->right);

  if(node->getCharacter() == '\0')
  {
    return left + right + "B";
  }

  std::string value(1, node->getCharacter());//turn char to string

  return left + right + "L" + value;

}

/*this fucntion takes the coded message of 0's and 1's and the serialized string of the tree and returns the original message. It does this by
rebuilding the original tree based on the serialization, then coding onto a map the values pertaining to the code, and finally decoding it back*/ 
std::string HuffmanTree::decompress(const std::string inputCode, const std::string serializedTree)
{
  std::string decompressed = "";//string to return

  std::string reversed = serializedTree;
  std::reverse(reversed.begin(), reversed.end()); //reverses string since it was done in post order
  std::deque<char> charQueue;//make a deque to hold values for node

  for(char c : reversed)
  {
    charQueue.push_back(c); //now deque hold all values of the string
  }

  HuffmanNode* deser_tree = deserialize(&charQueue);//contains root to original tree based on serialization
  std::string code = "";//this string will hold the 0's and 1's of the huffman code
  std::map<std::string, char> encodedMap;//this map will hold the characters and the key of the characters will be the code
  
  encode_deser(deser_tree, code, encodedMap);//now our map has all the keys and values, with the keys being the 0's and 1's

  std::string temp = ""; //this will hold the code we are decoding temporarily
  for(long long unsigned int i=0; i<inputCode.length(); i++)
  {
    temp += inputCode[i]; //add the current string character to temp string

    if(encodedMap.find(temp) == encodedMap.end())//if the string does not exist we will be returned an end() pointer
    {
      continue;
    }

    decompressed += encodedMap.at(temp); //otherwise add the value associated with that string to the decompressed string and clear the temp string
    temp.clear();

  }

    return decompressed;
    
  }


//helper fucntion used to build the original tree based on the serialization inputted, this fucntion recursively calls itself until the original tree is built. Then returns root
HuffmanNode* HuffmanTree::deserialize(std::deque<char>* serialized) 
{
  if (serialized->empty())
  {
    return nullptr; // If the deque is empty, return nullptr
  }

  char value = serialized->front(); //starts with the front of the deque
  serialized->pop_front();

  if(value != 'B')//this will be a leaf node
  {
    serialized->pop_front();//ignore the next value which will be an L and we dont take those..never
    HuffmanNode* node = new HuffmanNode(value,0,nullptr,nullptr,nullptr);
    return node;

  }

  //if statement that checks if the current value in the queue is an L. This means this is in fact not a branch B but a leaf and we should treat is as such
  if(serialized->front() == 'L')
  {
    char temp_val = serialized->front();//save the current L to check if theres an L after, if theres an L after thne this is in fact a branch and not a leafou
    serialized->pop_front();//remove front

    if(serialized->front() == 'L')
    {
      serialized->push_front(temp_val);//return L to the front
    }
    else
    {
      HuffmanNode* node = new HuffmanNode(value,0,nullptr,nullptr,nullptr);
      return node;
    }
  }

  HuffmanNode* node = new HuffmanNode('\0',0,nullptr,nullptr,nullptr);
  node->right = deserialize(serialized);
  node->left = deserialize(serialized);

  return node;
}  


//this function will encode the original tree after we deserialize it. It will then add the characters and the prefix code to a map with the code as the key
void HuffmanTree::encode_deser(HuffmanNode *root, std::string str, std::map<std::string, char> &huffmanCode)
{   
    if(root==NULL){
    return; //if we go below the leaf node
  }
  if(root->isLeaf()){
    huffmanCode[str]=root->getCharacter(); //if we reach a leaf node, add the character and its encoded string to the map
  }
  //we use recursive functions to traverse left and then right while updating the str accordingly
  encode_deser(root->left, str + "0",huffmanCode);//add 0 when traversing to left
  encode_deser(root->right, str + "1",huffmanCode);//add 1 when traversing to right
}