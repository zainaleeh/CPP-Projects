//Muhhamad Zain Ali U64584914
//Jose Jimenez U01810535

#ifndef HUFFMANTREE_H
#define HUFFMANTREE_H

#include "HuffmanBase.hpp"
#include "HeapQueue.hpp"
#include "vector"
#include "map"
#include "stack"
#include <queue>

class HuffmanTree : public HuffmanTreeBase {
  public:
  virtual std::string compress(const std::string inputStr);
  virtual std::string serializeTree() const;
  virtual std::string decompress(const std::string inputCode, const std::string serializedTree);


  void encode(HuffmanNode* root, std::string str, std::map<char, std::string> &huffmanCode);  //helper function used to encode a string with 0's and 1's
  std::string traverse_post_ser(HuffmanNode* node) const;//helper function used to traverse the huffman tree and create a string of serialization
  HuffmanNode* deserialize(std::deque<char>* serialized);
  void encode_deser(HuffmanNode *root, std::string str, std::map<std::string, char> &huffmanCode);//helper function used to encode a string with 0's and 1's but the keys are the code



  

  private:
    HuffmanNode* treeRoot;
    static std::string globalString;

};

#endif